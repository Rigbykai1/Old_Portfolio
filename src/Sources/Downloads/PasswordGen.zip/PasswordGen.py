import random
import string
import pyperclip


def pausa():
    input("Presione Enter para continuar...")


def opcion():
    while True:
        opcion = input(
            "¿Cuántos caracteres quieres que tenga la contraseña?: ")
        try:
            intOpcion = int(opcion)
            if isinstance(intOpcion, int):
                return int(intOpcion)
        except ValueError:
            print("La variable no es un entero, intente nuevamente.")
            pausa()


def generar_contraseña(longitud=12):
    caracteres = string.ascii_letters + string.digits + string.punctuation
    contraseña = ''.join(random.choice(caracteres) for _ in range(longitud))
    return contraseña


def main():
    longitud_deseada = opcion()
    contraseña_segura = generar_contraseña(longitud_deseada)
    print(f'Tu contraseña segura es: {contraseña_segura}')
    print("Copiada correctamente en el portapapeles...")
    pyperclip.copy(contraseña_segura)
    pausa()


main()
